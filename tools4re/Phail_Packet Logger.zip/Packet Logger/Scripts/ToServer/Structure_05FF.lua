AddBytes(1, "Packet Id")
AddBytes(2, "Unknown")
