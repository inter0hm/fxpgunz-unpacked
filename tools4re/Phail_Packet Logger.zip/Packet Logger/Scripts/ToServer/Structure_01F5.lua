AddBytes(1, "Packet Counter?")
AddBytes(8, "Announcer Session ID")
AddString("Message")
AddBytes(4, "Type")
