AddBytes(1, "Packet Counter?")
AddString("Username")
AddString("Password")
AddBytes(4, "Version")
AddBytes(4, "FileList CRC")

BeginSubNode("MD5 Hash Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
BeginSubNode("MD5 Hash")
for index = 1,count do
  AddBytes(size, "Data")
end
EndSubNode()
EndSubNode()
