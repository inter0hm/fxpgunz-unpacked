AddBytes (1, "Packet Id")
AddBytes (8, "Sender Id")
