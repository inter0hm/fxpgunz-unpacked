AddBytes(1, "Packet Counter?")
AddBytes(8, "Session ID")
AddBytes(4, "Index")
AddString("Name")
AddBytes(4, "Gender")
AddBytes(4, "Hair")
AddBytes(4, "Face")
AddBytes(4, "Costume")

