AddBytes(1, "Packet Counter?")
AddBytes(8, "Session ID")
AddBytes(4, "X Position")
AddBytes(4, "Y Position")
AddBytes(4, "Z Position")
AddBytes(4, "X Direction")
AddBytes(4, "Y Direction")
AddBytes(4, "Z Direction")

