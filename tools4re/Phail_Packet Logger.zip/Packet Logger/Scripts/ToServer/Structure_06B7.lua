AddBytes(1, "Packet Counter?")
AddBytes(1, "Character Index")
