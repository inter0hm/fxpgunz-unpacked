AddBytes(1, "Packet Counter?")
