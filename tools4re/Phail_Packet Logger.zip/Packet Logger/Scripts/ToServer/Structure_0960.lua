AddBytes(1, "Packet Id")
AddBytes(8, "Player Id")			
