AddBytes(1, "Packet Counter?")
AddBytes(8, "Stage ID")
AddBytes(4, "Round")
AddBytes(4, "State")
AddBytes(4, "Arg")

