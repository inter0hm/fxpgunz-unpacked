AddBytes(1, "Packet Counter?")
AddBytes(8, "Stage ID")

BeginSubNode("Peer Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Peer Info")
  AddBytes(8, "Session ID")
  AddBytes(4, "IP Address?")
  AddBytes(4, "UDP Port?")
  AddBytes(32, "Name")
  AddBytes(16, "Clan Name")
  AddBytes(2, "Clan Point")
  AddBytes(1, "Flag")
  AddBytes(2, "Level")
  AddBytes(1, "Sex")
  AddBytes(1, "Hair")
  AddBytes(1, "Face")
  AddBytes(4, "XP")
  AddBytes(4, "BP")
  AddBytes(4, "Bonus Rate")
  AddBytes(2, "Prize")
  AddBytes(2, "HP")
  AddBytes(2, "AP")
  AddBytes(2, "Weight")
  AddBytes(2, "SafeFall")
  AddBytes(2, "FR")
  AddBytes(2, "CR")
  AddBytes(2, "ER")
  AddBytes(2, "WR")
  
  BeginSubNode("Items")
  local itemc = 17
  for ii = 1,itemc do
     AddBytes(4, "ItemId")
  end
  EndSubNode()

  AddBytes(4, "UGradeId")
  AddBytes(4, "Clan Id")
  AddBytes(4, "Duel Rank")
  AddBytes(1, "Team")
  AddBytes(1, "Unknown, PGrade, Flags?")
  AddBytes(2, "Emblem")

  AddBytes(size - 184)
  EndSubNode()
end
EndSubNode()



