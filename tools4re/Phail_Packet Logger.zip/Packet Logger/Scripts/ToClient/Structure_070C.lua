AddBytes(1, "Packet Counter?")

BeginSubNode("Character Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Character Info")
  AddBytes(4, "Bounty")
  AddBytes(4, "Experience")
  AddBytes(1)
  EndSubNode()
end
EndSubNode()



