AddBytes(1, "Packet Counter?")

BeginSubNode("Channel Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Channel Info")
  AddBytes(8, "ID")
  AddBytes(2, "Index")
  AddBytes(2, "Players")
  AddBytes(2, "Capacity")
  AddBytes(2, "Minimum Level")
  AddBytes(2, "Maximum Level")
  AddBytes(1, "Type")
  AddBytes(64, "Name")
  AddBytes(1)
  AddBytes(4)
  EndSubNode()
end
EndSubNode()


