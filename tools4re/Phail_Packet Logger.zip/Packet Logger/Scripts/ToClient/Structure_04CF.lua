AddBytes(1, "Packet Counter?")
AddBytes(8, "Channel ID")
AddString("Ruleset")
