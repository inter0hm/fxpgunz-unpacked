AddBytes(1, "Packet Counter?")
AddBytes(8, "Session ID")
AddBytes(4, "Result")
