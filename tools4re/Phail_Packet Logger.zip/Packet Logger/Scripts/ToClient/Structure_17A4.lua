AddBytes (1, "Packet Id")
AddBytes (1, "Combat State")
