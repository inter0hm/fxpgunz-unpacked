AddBytes(1, "Packet Counter?")
AddBytes(1, "Previous Page Count")
AddBytes(1, "Next Page Count")

BeginSubNode("Stage Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Stage Info")
  AddBytes(8, "ID")
  AddBytes(1, "Index")
  AddBytes(64, "Name")
  AddBytes(1, "Players")
  AddBytes(1, "Capacity")
  AddBytes(4, "State")
  AddBytes(4, "Type")
  AddBytes(1)
  AddBytes(4, "Settings")
  AddBytes(1, "Base Level")
  AddBytes(1, "Level Limit")
  EndSubNode()
end
EndSubNode()



