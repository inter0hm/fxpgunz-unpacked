AddBytes (1, "Packet Id")
AddBytes (1, "Quest Id")
AddBytes (1, "Mapset Id")
AddBytes (4, "Scenario Id")
