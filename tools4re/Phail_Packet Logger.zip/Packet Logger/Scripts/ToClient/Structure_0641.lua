AddBytes (1, "Packet Id")
AddString("Sender")
AddString("Reciever")
AddString("Message")
