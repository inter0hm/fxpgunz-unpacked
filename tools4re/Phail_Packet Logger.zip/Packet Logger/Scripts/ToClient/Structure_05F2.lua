AddBytes(1, "Packet Counter?")
AddBytes(4, "Local Timestamp")
AddBytes(4, "Global Timestamp")
