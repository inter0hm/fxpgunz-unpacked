AddBytes(1, "Packet Counter?")
AddBytes(4, "Bounty")

BeginSubNode("Equipment Item Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Equipment Item Info")
  AddBytes(4)
  AddBytes(4, "Item Instance ID")
  EndSubNode()
end
EndSubNode()

BeginSubNode("Inventory Item Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Inventory Item Info")
  AddBytes(4)
  AddBytes(4, "Item Instance ID")
  AddBytes(4, "Item ID")
  AddBytes(4, "Expiration")
  EndSubNode()
end
EndSubNode()

BeginSubNode(" Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
AddBytes(size)
end
EndSubNode()
