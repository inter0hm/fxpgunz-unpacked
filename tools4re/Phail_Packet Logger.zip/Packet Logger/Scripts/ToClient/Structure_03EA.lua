AddBytes(1, "Packet Counter?")
AddBytes(4, "Result")
AddString("Server Name")
AddBytes(1, "Server Mode")
AddString("Username")
AddBytes(1, "User Access Level")
AddBytes(1, "Premium Access Level")
AddBytes(8, "Session ID")
AddBytes(1, "Enable Survival Mode")
AddBytes(1, "Enable Survival Mode")

BeginSubNode("MD5")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
BeginSubNode()
for index = 1,count do
  AddBytes(size)
end
EndSubNode()
EndSubNode()

