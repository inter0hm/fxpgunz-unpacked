AddBytes(1, "Packet Counter?")
BeginSubNode("Character Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Character")
  AddBytes(32, "Character Name")
  AddBytes(1, "Character Index")
  AddBytes(1, "Character Level")
  EndSubNode()
end
EndSubNode()


