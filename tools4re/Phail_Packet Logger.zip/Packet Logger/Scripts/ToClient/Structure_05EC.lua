AddBytes(1, "Packet Counter?")
AddBytes(8, "Session ID")
AddBytes(2, "X Position")
AddBytes(2, "Y Position")
AddBytes(2, "Z Position")
AddBytes(2, "X Direction")
AddBytes(2, "Y Direction")
AddBytes(2, "Z Direction")

