AddBytes(1, "Packet Counter?")
AddBytes(8, "Stage ID")

BeginSubNode("Game Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Game Info")
  AddBytes(size)
  EndSubNode()
end
EndSubNode()

BeginSubNode("Rule Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Rule Info")
  AddBytes(size)
  EndSubNode()
end
EndSubNode()

BeginSubNode("Character Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Character Info")
  AddBytes(8, "Session ID?")
  AddBytes(size - 8)
  EndSubNode()
end
EndSubNode()


