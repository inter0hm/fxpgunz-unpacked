AddBytes (1, "Packet Id")

AddBytes(8, "Stage ID")
AddBytes(4, "Tournament Type")
BeginSubNode("Player Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
BeginSubNode("Player Info")
AddBytes(32, "Name")
AddBytes(4, "Unknown")
AddBytes(4, "Ranking")
AddBytes(4, "Points")
EndSubNode()
end
EndSubNode()
