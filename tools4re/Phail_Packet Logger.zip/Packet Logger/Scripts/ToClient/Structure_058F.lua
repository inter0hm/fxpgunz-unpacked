AddBytes(1, "Packet Counter?")
AddBytes(8, "Session ID")
AddBytes(8, "Stage ID")
AddBytes(4, "Team")
