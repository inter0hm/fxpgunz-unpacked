AddBytes (1, "Packet Id")
AddBytes (8, "Player Id")
AddBytes (4, "Xp")
