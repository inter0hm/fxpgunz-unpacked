AddBytes(1, "Packet Id")

BeginSubNode("Player Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Player Info")
  AddBytes(32, "Name")
  AddBytes(4, "TP")
  AddBytes(4, "Wins")
  AddBytes(4, "Losses")
  AddBytes(4, "Ranking")
  AddBytes(4, "Champion")
  AddBytes(4, "PreviousTP")
  AddBytes(4, "Current Symbol")

  EndSubNode()
end
EndSubNode()
