AddBytes(1, "Packet Counter?")
AddBytes(4, "Timestamp")
