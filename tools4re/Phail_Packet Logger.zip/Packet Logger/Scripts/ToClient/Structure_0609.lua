AddBytes (1, "Packet Id")
AddBytes (4, "Item Id")
