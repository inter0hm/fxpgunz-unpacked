AddBytes (1, "Packet Id")
AddBytes (1, "Sector Id")
