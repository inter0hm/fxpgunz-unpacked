AddBytes(1, "Packet Counter?")

BeginSubNode("Spawn Info Array")
AddBytes(4, "Total Size")
local size = PeekInt32()
AddBytes(4, "Element Size")
local count = PeekInt32()
AddBytes(4, "Element Count")
for index = 1,count do
  BeginSubNode("Spawn Info")
  AddBytes(size)
  EndSubNode()
end
EndSubNode()

