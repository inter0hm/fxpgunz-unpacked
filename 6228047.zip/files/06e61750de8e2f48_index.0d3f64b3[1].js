'use strict';
function formatPostDate(ts) {
    return moment(ts).fromNow();
}
function formatSeasonReset(seasonEndDate, formatType) {
    var format = '';
    var delta = seasonEndDate;
    var days = Math.floor(delta / 86400);
    delta -= days * 86400;
    var hours = Math.floor(delta / 3600) % 24;
    delta -= hours * 3600;
    var minutes = Math.floor(delta / 60) % 60;
    delta -= minutes * 60;
    var seconds = delta % 60;
    if (days && formatType.includes('dd')) format += ' ' + days + 'D ' + (hours || minutes && formatType.includes('mm') ? ':' : '') + ' ';
    if (hours && formatType.includes('hh')) format += ' ' + hours + 'H ' + (minutes && formatType.includes('mm') ? ':' : '') + ' ';
    if (minutes && formatType.includes('mm')) format += ' ' + minutes + 'M';
    if (days === 0 && hours === 0 && minutes === 0) format += 'Now !';
    return format;
}

//# sourceMappingURL=index.0d3f64b3.js.map
