'use strict';
var onInit = function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee4() {
        var _this = this;
        var elOnlines, elSeasonEndDate, seasonEndDate, elMenuBtns, btns, i, elRankingsFilter;
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
            while(true)switch(_context4.prev = _context4.next){
                case 0:
                    preventZooming();
                    elOnlines = document.querySelector('.onlines span');
                    _context4.next = 4;
                    return fetchOnlines();
                case 4:
                    _context4.t0 = _context4.sent;
                    elOnlines.innerText = '' + _context4.t0;
                    elSeasonEndDate = document.querySelector('.season-reset span');
                    _context4.next = 9;
                    return fetchSeasonEndDate();
                case 9:
                    seasonEndDate = _context4.sent;
                    _context4.next = 12;
                    return formatSeasonReset(seasonEndDate, 'dd:hh:mm');
                case 12:
                    _context4.t1 = _context4.sent;
                    elSeasonEndDate.innerText = ' ' + _context4.t1;
                    setInterval(_asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee() {
                        return regeneratorRuntime.wrap(function _callee$(_context) {
                            while(true)switch(_context.prev = _context.next){
                                case 0:
                                    _context.next = 2;
                                    return formatSeasonReset(seasonEndDate, 'dd:hh:mm');
                                case 2:
                                    _context.t0 = _context.sent;
                                    elSeasonEndDate.innerText = ' ' + _context.t0;
                                case 4:
                                case 'end':
                                    return _context.stop();
                            }
                        }, _callee, _this);
                    })), 60000);
                    _context4.next = 17;
                    return loadAnnouncements();
                case 17:
                    _context4.next = 19;
                    return loadRankings();
                case 19:
                    _context4.next = 21;
                    return renderContent();
                case 21:
                    handleArrowsState();
                    elMenuBtns = document.querySelector('.menu-btns');
                    btns = elMenuBtns.getElementsByClassName('btn');
                    for(i = 0; i < btns.length; i++)btns[i].addEventListener('click', _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee2() {
                        var current;
                        return regeneratorRuntime.wrap(function _callee2$(_context2) {
                            while(true)switch(_context2.prev = _context2.next){
                                case 0:
                                    current = document.getElementsByClassName('active');
                                    current[0].className = current[0].className.replace(' active', '');
                                    this.className += ' active';
                                    this.className.includes('news') ? pageMode = 'news' : pageMode = 'rankings';
                                    removeArrowsDisabledState();
                                    resetPages();
                                    _context2.next = 8;
                                    return renderContent();
                                case 8:
                                    handleArrowsState();
                                    animateContent();
                                case 10:
                                case 'end':
                                    return _context2.stop();
                            }
                        }, _callee2, this);
                    })));
                    elRankingsFilter = document.querySelector('.rankings-filter');
                    elRankingsFilter.addEventListener('change', _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee3() {
                        return regeneratorRuntime.wrap(function _callee3$(_context3) {
                            while(true)switch(_context3.prev = _context3.next){
                                case 0:
                                    setFilter(elRankingsFilter.value);
                                    handleArrowsState();
                                    _context3.next = 4;
                                    return renderContent();
                                case 4:
                                case 'end':
                                    return _context3.stop();
                            }
                        }, _callee3, _this);
                    })));
                    animateElements();
                case 28:
                case 'end':
                    return _context4.stop();
            }
        }, _callee4, this);
    }));
    return function onInit() {
        return _ref.apply(this, arguments);
    };
}();
var onChangePage = function() {
    var _ref5 = _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee7(diff) {
        var _this2 = this;
        var direction, hasMore;
        return regeneratorRuntime.wrap(function _callee7$(_context7) {
            while(true)switch(_context7.prev = _context7.next){
                case 0:
                    direction = diff === 1 ? 'right' : 'left';
                    if (!(pageMode === 'news')) {
                        _context7.next = 11;
                        break;
                    }
                    if (!(newsPageIdx <= 0 && diff === -1)) {
                        _context7.next = 4;
                        break;
                    }
                    return _context7.abrupt('return');
                case 4:
                    if (!(newsPageIdx >= announcements.length - 1 && diff === 1)) {
                        _context7.next = 6;
                        break;
                    }
                    return _context7.abrupt('return');
                case 6:
                    newsPageIdx += diff;
                    animatePost('fadeOut', direction);
                    setTimeout(_asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee5() {
                        var elPost;
                        return regeneratorRuntime.wrap(function _callee5$(_context5) {
                            while(true)switch(_context5.prev = _context5.next){
                                case 0:
                                    _context5.next = 2;
                                    return renderContent();
                                case 2:
                                    elPost = document.querySelector('.post');
                                    elPost.style.cssText = 'transform: translateX(' + (direction === 'right' ? '-5%' : '5%') + '); opacity: 0;';
                                    animatePost('fadeIn', direction);
                                    handleArrowsState();
                                case 6:
                                case 'end':
                                    return _context5.stop();
                            }
                        }, _callee5, _this2);
                    })), 250);
                    _context7.next = 22;
                    break;
                case 11:
                    if (!(pageMode === 'rankings')) {
                        _context7.next = 22;
                        break;
                    }
                    if (!(rankingsPage <= 1 && diff === -1)) {
                        _context7.next = 14;
                        break;
                    }
                    return _context7.abrupt('return');
                case 14:
                    _context7.next = 16;
                    return hasMoreRankings();
                case 16:
                    hasMore = _context7.sent;
                    if (!(!hasMore && diff === 1)) {
                        _context7.next = 19;
                        break;
                    }
                    return _context7.abrupt('return');
                case 19:
                    rankingsPage += diff;
                    animateRankingsBody('fadeOut', direction);
                    setTimeout(_asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee6() {
                        var elRankingsBody;
                        return regeneratorRuntime.wrap(function _callee6$(_context6) {
                            while(true)switch(_context6.prev = _context6.next){
                                case 0:
                                    _context6.next = 2;
                                    return renderContent();
                                case 2:
                                    elRankingsBody = document.querySelector('.rankings-table');
                                    elRankingsBody.style.cssText = 'transform: translateX(' + (direction === 'right' ? '-7%' : '7%') + '); opacity: 0;';
                                    animateRankingsBody('fadeIn', direction);
                                    handleArrowsState();
                                case 6:
                                case 'end':
                                    return _context6.stop();
                            }
                        }, _callee6, _this2);
                    })), 250);
                case 22:
                case 'end':
                    return _context7.stop();
            }
        }, _callee7, this);
    }));
    return function onChangePage(_x) {
        return _ref5.apply(this, arguments);
    };
}();
var renderContent = function() {
    var _ref8 = _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee8() {
        var elContent;
        return regeneratorRuntime.wrap(function _callee8$(_context8) {
            while(true)switch(_context8.prev = _context8.next){
                case 0:
                    elContent = document.querySelector('.content');
                    if (!(pageMode === 'news')) {
                        _context8.next = 7;
                        break;
                    }
                    _context8.next = 4;
                    return renderNews(elContent);
                case 4:
                    toggleRankingsFilter(false);
                    _context8.next = 10;
                    break;
                case 7:
                    _context8.next = 9;
                    return renderRankings(elContent);
                case 9:
                    toggleRankingsFilter(true);
                case 10:
                case 'end':
                    return _context8.stop();
            }
        }, _callee8, this);
    }));
    return function renderContent() {
        return _ref8.apply(this, arguments);
    };
}();
var renderNews = function() {
    var _ref9 = _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee9(elContent) {
        var announcements, rows;
        return regeneratorRuntime.wrap(function _callee9$(_context9) {
            while(true)switch(_context9.prev = _context9.next){
                case 0:
                    announcements = getAnnouncements();
                    rows = announcements[newsPageIdx].content.split('\n');
                    elContent.innerHTML = '\n    <article class="post">\n                <div class="post-author-wrapper">\n                    <p class="post-author">' + announcements[newsPageIdx].author + '</p>\n                    <span class="post-publish-date">' + formatPostDate(announcements[newsPageIdx].createdAt) + '</span>\n                </div>\n                <div class="post-body">' + rows.map(function(row) {
                        if (!row) return '<div class="break-line"></div>';
                        return '<div>' + row + '</div>';
                    }).join('') + '\n                </div>\n    </article>\n    ';
                // const elPostDate = document.querySelector('.post-publish-date span');
                // elPostDate.innerText = ` ${getPostDateFormat(announcements[idx].createdAt)}`;
                case 3:
                case 'end':
                    return _context9.stop();
            }
        }, _callee9, this);
    }));
    return function renderNews(_x2) {
        return _ref9.apply(this, arguments);
    };
}();
var renderRankings = function() {
    var _ref10 = _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee10(elContent) {
        var rankings, ctg;
        return regeneratorRuntime.wrap(function _callee10$(_context10) {
            while(true)switch(_context10.prev = _context10.next){
                case 0:
                    _context10.next = 2;
                    return getRankings();
                case 2:
                    rankings = _context10.sent;
                    ctg = getCtg();
                    elContent.innerHTML = '\n    <div class="rankings">\n        <div class="rankings-headers">\n                <thead>\n                    <ul>\n                        ' + _getRankingsHeader(ctg) + '\n                    </ul>\n                </thead>\n        </div>\n            <div class="rankings-table-wrapper">\n                <div class="rankings-table" style="transform: translateX(0%); opacity: 1;">\n                    <ul>\n                         ' + rankings.map(function(row) {
                        if (ctg === 'individual') return '\n                                        <li>\n                                            <span>' + row.rank + '</span>\n                                            <span>' + row.name + '</span>\n                                            <span>' + row.level + '</span>\n                                            <span>' + row.xp + '</span>\n                                            <span class="emblem-container">\n                                            ' + (row.clan ? row.clan.name : '-') + '\n                                            </span>\n                                            <span>' + row.cPoints + '</span>\n                                            <span>' + row.kills + '</span>\n                                            <span>' + row.deaths + '</span>\n                                            <span>' + row.ratio + '</span>\n                                        </li>\n                                        ';
                        else if (ctg === 'ladder') return '\n                                <li>\n                                    <span>' + row.rank + '</span>\n                                    <span>' + row.name + '</span>\n                                    <span>' + row.score + '</span>\n                                    <span>' + row.wins + '</span>\n                                    <span>' + row.losses + '</span>\n                                </li>\n                                ';
                        else if (ctg === 'clan') return '\n                                <li>\n                                    <span>' + row.rank + '</span>\n                                    <span class="emblem-container">\n                                    ' + row.name + '\n                                    </span>\n                                    <span>' + row.wins + '</span>\n                                    <span>' + row.losses + '</span>\n                                    <span>' + row.ratio + '</span>\n                                    <span>' + row.points + '</span>\n                                    <span>' + row.totalPoints + '</span>\n                                </li>\n                                ';
                    }).join('') + '\n                    </ul>\n                </div>\n        </div>\n    </div>\n                 ';
                //                  ${rankings.map((player) => {
                //        return `<li>${player.map((detail) => `<span>${detail ? detail : '-'}</span>`
                //        ).join('')}</li>`;
                //    }).join('')}
                case 5:
                case 'end':
                    return _context10.stop();
            }
        }, _callee10, this);
    }));
    return function renderRankings(_x3) {
        return _ref10.apply(this, arguments);
    };
}();
var handleArrowsState = function() {
    var _ref11 = _asyncToGenerator(/*#__PURE__*/ regeneratorRuntime.mark(function _callee11() {
        var elNextIcon, elPrevIcon, isPrevDisabled, isNextDisabled, hasMore;
        return regeneratorRuntime.wrap(function _callee11$(_context11) {
            while(true)switch(_context11.prev = _context11.next){
                case 0:
                    elNextIcon = document.querySelector('.next-icon');
                    elPrevIcon = document.querySelector('.prev-icon');
                    isPrevDisabled = elPrevIcon.classList.contains('disabled');
                    isNextDisabled = elNextIcon.classList.contains('disabled');
                    if (!(pageMode === 'news')) {
                        _context11.next = 9;
                        break;
                    }
                    if (newsPageIdx !== announcements.length - 1 && isNextDisabled) elNextIcon.classList.remove('disabled');
                    else if (newsPageIdx === announcements.length - 1) elNextIcon.classList.add('disabled');
                    if (isPrevDisabled && newsPageIdx > 0) elPrevIcon.classList.remove('disabled');
                    else if (newsPageIdx === 0 && !isPrevDisabled) elPrevIcon.classList.add('disabled');
                    _context11.next = 15;
                    break;
                case 9:
                    if (!(pageMode === 'rankings')) {
                        _context11.next = 15;
                        break;
                    }
                    _context11.next = 12;
                    return hasMoreRankings();
                case 12:
                    hasMore = _context11.sent;
                    if (hasMore && isNextDisabled) elNextIcon.classList.remove('disabled');
                    else if (!hasMore) elNextIcon.classList.add('disabled');
                    if (isPrevDisabled && rankingsPage > 1) elPrevIcon.classList.remove('disabled');
                    else if (rankingsPage === 1 && !isPrevDisabled) elPrevIcon.classList.add('disabled');
                case 15:
                case 'end':
                    return _context11.stop();
            }
        }, _callee11, this);
    }));
    return function handleArrowsState() {
        return _ref11.apply(this, arguments);
    };
}();
function _asyncToGenerator(fn) {
    return function() {
        var gen = fn.apply(this, arguments);
        return new Promise(function(resolve, reject) {
            function step(key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) resolve(value);
                else return Promise.resolve(value).then(function(value) {
                    step("next", value);
                }, function(err) {
                    step("throw", err);
                });
            }
            return step("next");
        });
    };
}
window.onload = onInit;
function animateElements() {
    var elPost = document.querySelector('.post');
    elPost.style.cssText = 'transform: translateX(-100%); opacity: 0;';
    animateMenu();
    setTimeout(function() {
        return animatePost('fadeIn');
    }, 500);
}
function animateContent() {
    if (pageMode === 'news') {
        var elPost = document.querySelector('.post');
        elPost.style.cssText = 'transform: translateX(-100%); opacity: 0;';
        animatePost('fadeIn');
    } else {
        var elRankings = document.querySelector('.rankings');
        elRankings.style.cssText = 'transform: translateX(-100%); opacity: 0;';
        animateRankings('fadeIn');
    }
}
function animateMenu() {
    var elMenuBg = document.querySelector('.menu-bg');
    elMenuBg.style.cssText = 'transform: translateX(-100%); opacity: 0;';
    var elMenuBtns = document.querySelector('.menu-btns');
    elMenuBtns.style.cssText = 'transform: translateX(-100%); opacity: 0;';
    setTimeout(function() {
        return anime({
            targets: '.menu-bg',
            translateX: '0%',
            opacity: 1,
            easing: 'spring(0.1, 80, 10, 0)'
        });
    }, 250);
    setTimeout(function() {
        return anime({
            targets: '.menu-btns',
            translateX: '0%',
            opacity: 1,
            easing: 'spring(0.1, 80, 10, 0)'
        });
    }, 350);
}
function animatePost(state, direction) {
    var translateX = direction === 'right' ? '5%' : '-5%';
    var options = void 0;
    if (state === 'fadeOut') options = {
        targets: '.post',
        translateX: translateX,
        opacity: 0,
        easing: 'spring(0.1, 80, 10, 0)'
    };
    else options = {
        targets: '.post',
        translateX: '0%',
        opacity: 1,
        easing: 'spring(0.1, 80, 10, 0)'
    };
    anime(options);
}
function animateRankingsBody(state, direction) {
    var translateX = direction === 'right' ? '7%' : '-7%';
    var options = void 0;
    if (state === 'fadeOut') options = {
        targets: '.rankings-table',
        translateX: translateX,
        opacity: 0,
        easing: 'spring(0.1, 80, 10, 0)'
    };
    else options = {
        targets: '.rankings-table',
        translateX: '0%',
        opacity: 1,
        easing: 'spring(0.1, 80, 10, 0)'
    };
    anime(options);
}
function animateRankings(state) {
    var options = void 0;
    if (state === 'fadeOut') options = {
        targets: '.rankings',
        translateX: '7%',
        opacity: 0,
        easing: 'spring(0.1, 80, 10, 0)'
    };
    else options = {
        targets: '.rankings',
        translateX: '0%',
        opacity: 1,
        easing: 'spring(0.1, 80, 10, 0)'
    };
    anime(options);
}
function toggleRankingsFilter(toShow) {
    var elRankingsFilter = document.querySelector('.rankings-filter');
    elRankingsFilter.style.display = toShow ? 'block' : 'none';
}
function preventZooming() {
    document.addEventListener('keydown', function(ev) {
        if (ev.ctrlKey && (ev.key === '-' || '+')) ev.preventDefault();
    });
    document.addEventListener('wheel', function(ev) {
        if (ev.ctrlKey) ev.preventDefault();
    });
}
function _getRankingsHeader(ctg) {
    if (ctg === 'individual') return '\n                    <li>#</li>\n                    <li>Name</li>\n                    <li>Level</li>\n                    <li>Xp</li>\n                    <li>Clan</li>\n                    <li>CPoints</li>\n                    <li>Kills</li>\n                    <li>Deaths</li>\n                    <li>Ratio</li>\n                    ';
    else if (ctg === 'ladder') return '\n                    <li>#</li>\n                    <li>Name</li>\n                    <li>Score</li>\n                    <li>Wins</li>\n                    <li>Losses</li>\n                    ';
    else if (ctg === 'clan') return '\n                    <li>#</li>\n                    <li>Name</li>\n                    <li>Wins</li>\n                    <li>Losses</li>\n                    <li>Ratio</li>\n                    <li>Points</li>\n                    <li>Total Points</li>\n                    ';
}
function removeArrowsDisabledState() {
    var elNextIcon = document.querySelector('.next-icon');
    var elPrevIcon = document.querySelector('.prev-icon');
    elNextIcon.classList.remove('disabled');
    elPrevIcon.classList.remove('disabled');
}
function handleArrowsOnFilter() {
    var elNextIcon = document.querySelector('.next-icon');
    var elPrevIcon = document.querySelector('.prev-icon');
    elNextIcon.classList.remove('disabled');
    elPrevIcon.classList.add('disabled');
}

//# sourceMappingURL=index.c63d8bb4.js.map
